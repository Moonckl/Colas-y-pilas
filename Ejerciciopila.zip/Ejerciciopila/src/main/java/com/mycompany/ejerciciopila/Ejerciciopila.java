/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejerciciopila;

/**
 *
 * @author nebuu
 */
import java.util.Scanner;
public class Ejerciciopila {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        int[]pila = new int [5];
        
        int tope = -1;
        int opcion;
        
        do {
            System.out.println("\n -- PILA CON ARREGLOS");
            System.out.println("1. Agregar un numero a la PILA    ");
            System.out.println("2. Retirar un numero de la PILA   ");
            System.out.println("3. Mostrar la PILA   ");
            System.out.println("4. Mostrar el tope    ");
            System.out.println("5.Salir   ");
            System.out.println("6.Opcion  ");
            opcion=teclado.nextInt();
                    
            switch(opcion){
            
                case 1:
                    if(tope == pila.length-1){
                        System.out.println("heyo the bill is full");System.out.println("Hello World!");
            }else{
                    System.out.println("Put some in this sh**t");
                    int numero = teclado.nextInt();
                    tope++;
                    pila[tope]=numero;
                            }
                    break;
                case 2 :
                    if ( tope== -1 ){
                        System.out.println("Put some in this sh**t");
                    }else{
                    System.out.println("retirar " + pila[tope]);
                    tope --;
                    }
                    
                case 3 :
                    if ( tope== -1 ){
                        System.out.println("Put some in this sh**t");
                    }else{
                    System.out.println(" Mostrar la pila de elementos " );
                    
                    for(int i = tope; i>=0 ; i--){
                    
                    System.out.println("PILA " + pila[i]);
                    }
                    } break;
                    
                case 4 :
                    
                    if ( tope== -1 ){
                        System.out.println("Put some in this sh**t");
                    }else{
                    System.out.println("Put some in this sh**t " + pila[tope]);
                    }
                    break;
                    
                case 5 : 
                    System.out.println("Fin del programa");
                    break;
                    
                default:
                    System.out.println("Opcion invalida");
            }
        
        }while(opcion !=5);
            teclado.close();
   
    }
}
